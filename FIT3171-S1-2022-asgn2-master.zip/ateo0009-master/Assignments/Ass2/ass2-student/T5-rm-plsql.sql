--****PLEASE ENTER YOUR DETAILS BELOW****
--T5-rm-alter.sql

--Student ID: 30884454
--Student Name: Teo Andrew Szen Ray
--Unit Code: FIT3171
--Applied Class No: Tutorial Group 03

/* Comments for your marker:




*/

--5(a)
CREATE OR REPLACE TRIGGER check_multiple_event
    BEFORE 
    INSERT 
    ON entry
    FOR EACH ROW
DECLARE
    comp_exist NUMERIC(3);
    comp_carn_date DATE;
BEGIN
    -- find competitor number that already exists on a carnival date
    SELECT 
        carn_date
    INTO
        comp_carn_date
    FROM 
        event
    WHERE
        event_id = :new.event_id;
    
    SELECT 
        COUNT(*)
    INTO 
        comp_exist
    FROM 
        entry en LEFT OUTER JOIN event ev
        ON en.event_id = ev.event_id
    WHERE
            comp_no = :new.comp_no
        AND carn_date = comp_carn_date;
    
    IF (comp_exist > 0)
    THEN 
        raise_application_error(-20000, 'Competitor cannot compete in more than one event for a given carnival.');
    ELSE
        dbms_output.put_line('Related unit codes in ENROLMENT have been updated');
    END IF;
END;
/

-- Test Harness for 5(a) --
-- Original state 
SELECT * FROM entry;

-- Test trigger: Insert entry with unique competitor - SHOULD SUCCEED
INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    327, -- random hardcoded entry number
    NULL,
    NULL,
    12,
    400, -- random hardcoded competitor number
    NULL,
    NULL
);

-- Post state
SELECT * FROM entry;

-- Test trigger: Insert competitor that is already taking part in one event at a given carnival -- SHOULD RAISE ERROR
-- Prior state
SELECT * FROM entry;

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    484, -- random hardcoded entry number
    NULL,
    NULL,
    10, -- competitor 79 is already competing in an event on that day (event_id 11)
    79, -- random hardcoded competitor number
    NULL,
    NULL
);

-- Post state
SELECT * FROM entry;

-- close transaction
rollback;

--5(b)


-- Test harness for 5(b)


--5(c)


-- Test Harness for 5(c)

