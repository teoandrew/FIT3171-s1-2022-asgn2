--****PLEASE ENTER YOUR DETAILS BELOW****
--T3-rm-dm.sql

--Student ID: 30884454
--Student Name: Teo Andrew Szen Ray
--Unit Code: FIT3171
--Applied Class No: Tutorial Group 03

/* Comments for your marker:




*/

--3(a)
DROP SEQUENCE competitor_seq;

DROP SEQUENCE team_seq;

CREATE SEQUENCE competitor_seq START WITH 100 INCREMENT BY 1;

CREATE SEQUENCE team_seq START WITH 100 INCREMENT BY 1;

--3(b)
INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0476541234',
    'Jack',
    'Kai'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    competitor_seq.NEXTVAL,
    'Daniel',
    'Kai',
    'M',
    TO_DATE('7/JUN/2001', 'DD/MON/YYYY'),
    'danielkai@gmail.com',
    'Y',
    '0139643322', 
    'P',
    '0476541234'
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    104,
    NULL,
    NULL,
    (SELECT 
        event_id 
    FROM 
        event 
    WHERE 
            carn_date = (
                SELECT 
                    carn_date 
                FROM 
                    carnival 
                WHERE 
                        carn_name = 'RM Autumn Series Caulfield 2022'
            )
        AND eventtype_code = '21K'
    ),
    competitor_seq.CURRVAL,
    NULL,
    (SELECT 
        char_id 
    FROM 
        charity 
    WHERE 
        char_name = 'Beyond Blue'
    )
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    competitor_seq.NEXTVAL,
    'Annabelle',
    'Kai',
    'F',
    TO_DATE('17/AUG/1998', 'DD/MON/YYYY'),
    'annabellekai@gmail.com',
    'Y',
    '0173447891',
    'P',
    '0476541234'
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    105,
    NULL,
    NULL,
    (SELECT 
        event_id 
    FROM 
        event 
    WHERE
            carn_date = (
                SELECT 
                    carn_date 
                FROM 
                    carnival 
                WHERE 
                        carn_name = 'RM Autumn Series Caulfield 2022'
            )
        AND eventtype_code = '21K'
    ),
    competitor_seq.CURRVAL,
    NULL,
    (SELECT 
        char_id 
    FROM 
        charity 
    WHERE 
        char_name = 'Amnesty International'
    )
);

COMMIT;

--3(c)
INSERT INTO team (
    team_id,
    team_name,
    team_no_members,
    carn_date,
    event_id,
    entry_no,
    char_id
) VALUES (
    team_seq.NEXTVAL,
    'Kai Speedstars',
    1,
    (SELECT
        carn_date 
    FROM 
        carnival 
    WHERE 
        carn_name = 'RM Autumn Series Caulfield 2022'
    ),
    (SELECT
        event_id
    FROM
        entry e LEFT OUTER JOIN competitor c
        ON e.comp_no = c.comp_no
    WHERE
            comp_fname = 'Annabelle'
        AND comp_lname = 'Kai'
    ),
    105,
    (SELECT 
        char_id 
    FROM 
        charity 
    WHERE
        char_name = 'Beyond Blue'
    )
);

COMMIT;

--3(d)
UPDATE entry
SET 
    event_id = (
        SELECT 
            event_id 
        FROM   
            event 
        WHERE 
            carn_date = (
                SELECT 
                    carn_date 
                FROM 
                    carnival 
                WHERE 
                        carn_name = 'RM Autumn Series Caulfield 2022'
                    AND eventtype_code = '10K'
            )
        ),
    team_id = (
        SELECT 
            team_id 
        FROM 
            team 
        WHERE
            team_name = 'Kai Speedstars'
    )
WHERE 
    comp_no = (
        SELECT 
            comp_no 
        FROM 
            competitor 
        WHERE 
                comp_fname = 'Daniel' 
            AND comp_lname = 'Kai'
    );

COMMIT;

--3(e)
DELETE FROM entry 
WHERE
    comp_no = (
        SELECT 
            comp_no 
        FROM 
            competitor 
        WHERE 
                comp_fname = 'Daniel' 
            AND comp_lname = 'Kai'
    );
    
DELETE FROM competitor
WHERE
        comp_fname = 'Daniel'
    AND comp_lname = 'Kai';

UPDATE entry
SET
    char_id = (
        SELECT 
            char_id
        FROM 
            charity
        WHERE
            char_name = 'Beyond Blue'
    ),
    team_id = NULL
WHERE 
    comp_no = (
        SELECT 
            comp_no
        FROM 
            competitor
        WHERE 
                comp_fname = 'Annabelle'
            AND comp_lname = 'Kai'
    );

DELETE FROM team
WHERE 
    team_name = 'Kai Speedstars';

COMMIT;
