--****PLEASE ENTER YOUR DETAILS BELOW****
--T2-rm-insert.sql

--Student ID: 30884454
--Student Name: Teo Andrew Szen Ray
--Unit Code: FIT3171
--Applied Class No: Tutorial Group 03

/* Comments for your marker:

I've given every entry start and end times. I believe each the end times of each
entry are valid and appropriate starting and ending times for the type of event/race
that the entrant is competing in based on quick research online of each event's 
average time taken to complete. 

*/

-- Task 2 Load the EMERCONTACT, COMPETITOR, ENTRY and TEAM tables with your own
-- test data following the data requirements expressed in the brief

-- =======================================
-- EMERCONTACT
INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0130029645',
    'Joe',
    'Fred'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0113019225',
    'Donald',
    'Glover'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0129451000',
    'Kendrick',
    'Lamar'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0177008945',
    'Erna',
    'Medrod'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0133844874',
    'Maria',
    'Seppe'
);
-- =======================================


-- =======================================
-- COMPETITOR
-- 11 competitors who are Monash student/staff
INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    00049,
    'Rim',
    'Hebertson',
    'M',
    TO_DATE('1/JAN/1987', 'DD/MON/YYYY'),
    'rimhebertson@gmail.com',
    'Y',
    '0112375939',
    'T',
    '0133844874'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    00059,
    'Sara',
    'Radic',
    'F',
    TO_DATE('2/FEB/2001', 'DD/MON/YYYY'),
    'sararadic@gmail.com',
    'Y',
    '0127776354',
    'F',
    '0133844874'
);  

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    00078,
    'Ranulf',
    'MacCarrick',
    'M',
    TO_DATE('13/DEC/1995', 'DD/MON/YYYY'),
    'ranulfmac@gmail.com',
    'Y',
    '0165578931',
    'F',
    '0129451000'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    00021,
    'Fiachrae',
    'Adamik',
    'F',
    TO_DATE('22/FEB/1995', 'DD/MON/YYYY'),
    'fiaadamik@gmail.com',
    'Y',
    '0173249900',
    'F',
    '0129451000'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    00077,
    'Floyd',
    'Tahtinen',
    'M',
    TO_DATE('19/AUG/1993', 'DD/MON/YYYY'),
    'floydtahiten@gmail.com',
    'Y',
    '0132943311',
    'F',
    '0129451000'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    00079,
    'Shizuka',
    'Glynn',
    'F', 
    TO_DATE('19/SEP/1984', 'DD/MON/YYYY'),
    'shizukaglynn@gmail.com',
    'Y',
    '0176233443',
    'T',
    '0113019225'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    00067,
    'Georgiy',
    'Ek',
    'M',
    TO_DATE('4/JUL/1990', 'DD/MON/YYYY'),
    'georgiyek@gmail.com',
    'Y',
    '0195525354',
    'F',
    '0113019225'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    00099,
    'Gerasim',
    'Petran',
    'M', 
    TO_DATE('17/JUN/1988', 'DD/MON/YYYY'),
    'gerasimpetran@gmail.com',
    'Y',
    '0113446622',
    'F',
    '0113019225'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    00064,
    'Mithridates',
    'Stark',
    'F',
    TO_DATE('7/JUN/1994', 'DD/MON/YYYY'),
    'mithstark@gmail.com',
    'Y',
    '0195667732',
    'G',
    '0177008945'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    00022,
    'Germy',
    'Menendez',
    'M', 
    TO_DATE('18/OCT/1994', 'DD/MON/YYYY'),
    'germymenendez@gmail.com',
    'Y',
    '0188224455',
    'F', 
    '0113019225'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    00023,
    'Manasses',
    'Rheardon',
    'F',
    TO_DATE('8/APR/1994', 'DD/MON/YYYY'),
    'manassesrheardon@gmail.com',
    'Y',
    '0174345777',
    'F',
    '0113019225'
);

-- 2 competitors who are not Monash student/staff
INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    00002,
    'Mithradi',
    'Stark',
    'M',
    TO_DATE('7/JUN/1994', 'DD/MON/YYYY'),
    'mithdistark@gmail.com',
    'N',
    '0133377443',
    'G',
    '0177008945'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    00096,
    'Whitney',
    'Alford',
    'F',
    TO_DATE('17/NOV/1979', 'DD/MON/YYYY'),
    'whitneyalford@gmail.com',
    'N',
    '0192738788',
    'T',
    '0129451000'
);

-- 2 competitors who are under 18 years of age
INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    00007,
    'Joe',
    'Fred Jr',
    'M',
    TO_DATE('4/MAR/2005', 'DD/MON/YYYY'),
    'joefredjr@gmail.com',
    'N',
    '0111800994',
    'P',
    '0130029645'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    00008,
    'Samantha',
    'Fred Jr',
    'F',
    TO_DATE('7/OCT/2007', 'DD/MON/YYYY'),
    'samanthafredjr@gmail.com',
    'N',
    '0187653344',
    'P',
    '0130029645'
);
-- =======================================


-- =======================================
-- ENTRY
-- 6 events from 3 different carnivals
INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    33,
    TO_DATE('09:30:00','HH:MI:SS'),
    TO_DATE('10:10:43', 'HH:MI:SS'),
    1,
    00049,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    71,
    TO_DATE('08:30:00', 'HH:MI:SS'),
    TO_DATE('09:48:32', 'HH:MI:SS'),
    2,
    00059,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    34,
    TO_DATE('08:30:00', 'HH:MI:SS'),
    TO_DATE('09:13:45', 'HH:MI:SS'),
    7,
    00078,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    62,
    TO_DATE('08:00:00', 'HH:MI:SS'),
    TO_DATE('09:39:02', 'HH:MI:SS'),
    9,
    00021,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    23,
    TO_DATE('08:00:00', 'HH:MI:SS'),
    TO_DATE('08:16:07', 'HH:MI:SS'),
    10,
    00008,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    50,
    TO_DATE('07:45:00', 'HH:MI:SS'),
    TO_DATE('12:59:02', 'HH:MI:SS'),
    11,
    00079,
    NULL,
    NULL
);

-- 5 competitors who join more than 2 events

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    43,
    TO_DATE('09:00:00','HH:MI:SS'),
    TO_DATE('09:31:04', 'HH:MI:SS'),
    3,
    00049,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    9,
    TO_DATE('08:30:00','HH:MI:SS'),
    TO_DATE('08:56:45', 'HH:MI:SS'),
    7,
    00049,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    11,
    TO_DATE('08:30:00', 'HH:MI:SS'),
    TO_DATE('09:41:27', 'HH:MI:SS'),
    4,
    00059,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    63,
    TO_DATE('08:00:00', 'HH:MI:SS'),
    TO_DATE('09:09:14', 'HH:MI:SS'),
    8,
    00059,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    60,
    TO_DATE('09:00:00', 'HH:MI:SS'),
    TO_DATE('09:25:56', 'HH:MI:SS'),
    3,
    00078,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    45,
    TO_DATE('08:30:00', 'HH:MI:SS'),
    TO_DATE('09:49:49', 'HH:MI:SS'),
    13,
    00078,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    26,
    TO_DATE('08:30:09', 'HH:MI:SS'),
    TO_DATE('09:33:10', 'HH:MI:SS'),
    2,
    00021,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    3,
    TO_DATE('08:00:00', 'HH:MI:SS'),
    TO_DATE('09:44:17', 'HH:MI:SS'),
    5,
    00021,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    83,
    TO_DATE('07:45:00', 'HH:MI:SS'),
    TO_DATE('12:58:57', 'HH:MI:SS'),
    11,
    00021,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    36,
    TO_DATE('08:00:00', 'HH:MI:SS'),
    TO_DATE('09:30:17', 'HH:MI:SS'),
    14,
    00021,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    16,
    TO_DATE('08:30:00', 'HH:MI:SS'),
    TO_DATE('08:46:12', 'HH:MI:SS'),
    6, 
    00008,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    93,
    TO_DATE('08:45:00', 'HH:MI:SS'),
    TO_DATE('09:04:20', 'HH:MI:SS'),
    12,
    00008,
    NULL,
    NULL
);

-- 2 uncompleted entries
INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    94,
    NULL,
    NULL,
    6,
    00007,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    15,
    NULL,
    NULL,
    8,
    00096,
    NULL,
    NULL
);

-- 10 more entries of ENTRY to meet minimum of 30 entries
INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    39,
    NULL,
    NULL,
    12,
    00067,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    72,
    TO_DATE('08:30:00', 'HH:MI:SS'),
    TO_DATE('09:02:34', 'HH:MI:SS'),
    7, 
    00077,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    62,
    TO_DATE('07:45:00', 'HH:MI:SS'),
    NULL,
    11, 
    00077,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    52,
    TO_DATE('08:00:00', 'HH:MI:SS'),
    TO_DATE('09:12:57', 'HH:MI:SS'),
    5, 
    00099,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    42,
    TO_DATE('08:45:00', 'HH:MI:SS'),
    TO_DATE('09:11:53', 'HH:MI:SS'),
    12, 
    00099,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    4,
    TO_DATE('08:00:00', 'HH:MI:SS'),
    TO_DATE('09:01:01', 'HH:MI:SS'),
    5, 
    00064,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    7,
    TO_DATE('07:45:00', 'HH:MI:SS'),
    TO_DATE('12:15:02', 'HH:MI:SS'),
    11, 
    00064,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    10,
    TO_DATE('07:45:00', 'HH:MI:SS'),
    TO_DATE('12:21:22', 'HH:MI:SS'),
    11, 
    00002,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    19,
    TO_DATE('08:30:00', 'HH:MI:SS'),
    TO_DATE('08:48:40', 'HH:MI:SS'),
    6, 
    000022,
    NULL,
    NULL
);

INSERT INTO entry (
    entry_no,
    entry_starttime,
    entry_finishtime,
    event_id,
    comp_no,
    team_id,
    char_id
) VALUES (
    1,
    TO_DATE('08:30:00', 'HH:MI:SS'),
    TO_DATE('08:46:10', 'HH:MI:SS'),
    6, 
    000023,
    NULL,
    NULL
);
-- =======================================


-- =======================================
-- TEAM

INSERT INTO team (
    team_id,
    team_name,
    team_no_members,
    carn_date,
    event_id,
    entry_no,
    char_id
) VALUES (
    3,
    'Winner winner',
    3,
    TO_DATE('24/SEP/2021', 'DD/MON/YYYY'),
    1,
    33,
    NULL
);

INSERT INTO team (
    team_id,
    team_name,
    team_no_members,
    carn_date,
    event_id,
    entry_no,
    char_id
) VALUES (
    22,
    'Chicken dinner',
    5,
    TO_DATE('01/OCT/2021', 'DD/MON/YYYY'),
    3,
    60,
    NULL
);

INSERT INTO team (
    team_id,
    team_name,
    team_no_members,
    carn_date,
    event_id,
    entry_no,
    char_id
) VALUES (
    45,
    'Turkey sandwich',
    10,
    TO_DATE('05/FEB/2022', 'DD/MON/YYYY'),
    6,
    16,
    NULL
);

INSERT INTO team (
    team_id,
    team_name,
    team_no_members,
    carn_date,
    event_id,
    entry_no,
    char_id
) VALUES (
    68,
    'Duck rice',
    2,
    TO_DATE('14/MAR/2022', 'DD/MON/YYYY'),
    10,
    23,
    NULL
);

INSERT INTO team (
    team_id,
    team_name,
    team_no_members,
    carn_date,
    event_id,
    entry_no,
    char_id
) VALUES (
    84,
    'Medium rare steak',
    2,
    TO_DATE('29/MAY/2022', 'DD/MON/YYYY'),
    11,
    50, 
    NULL
);

INSERT INTO team (
    team_id,
    team_name,
    team_no_members,
    carn_date,
    event_id,
    entry_no,
    char_id
) VALUES (
    93,
    'Winner winner',
    2,
    TO_DATE('29/MAY/2022', 'DD/MON/YYYY'),
    13,
    45,
    NULL
);
-- =======================================

COMMIT;
