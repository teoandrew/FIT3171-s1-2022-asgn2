--****PLEASE ENTER YOUR DETAILS BELOW****
--T4-rm-alter.sql

--Student ID: 30884454
--Student Name: Teo Andrew Szen Ray
--Unit Code: FIT3171
--Applied Class No: Tutorial Group 03

/* Comments for your marker:




*/

--4(a)
ALTER TABLE entry
ADD (
    entry_elapsedtime DATE DEFAULT NULL
);

COMMENT ON COLUMN entry.entry_elapsedtime IS
    'The entry''s elapsed time (finish time - start time)';
    
COMMIT;

--4(b)
DROP TABLE team_charity CASCADE CONSTRAINTS;

CREATE TABLE team_charity (
    team_id     NUMBER(3) NOT NULL,
    char_id     NUMBER(3) NOT NULL,
    teamchar_percent NUMBER(3) NOT NULL
);

COMMENT ON COLUMN team_charity.team_id IS
    'The team''s ID number';

COMMENT ON COLUMN team_charity.char_id IS
    'Charity unique identifier';

COMMENT ON COLUMN team_charity.teamchar_percent IS
    'The percentage of funds of a team to a charity';
    
ALTER TABLE team_charity ADD CONSTRAINT teamcharity_pk PRIMARY KEY ( team_id, char_id );

ALTER TABLE team_charity 
    ADD (CONSTRAINT teamcharity_team_fk FOREIGN KEY ( team_id )
            REFERENCES team ( team_id ),
        CONSTRAINT teamcharity_char_fk FOREIGN KEY ( char_id )
            REFERENCES charity ( char_id ));
            
COMMIT;
    
--4(c)
DROP TABLE officialrole CASCADE CONSTRAINTS;

DROP TABLE official CASCADE CONSTRAINTS;

CREATE TABLE officialrole (
    offrole_code CHAR(3) NOT NULL,
    offrole_desc VARCHAR2(50) NOT NULL
);

COMMENT ON COLUMN officialrole.offrole_code IS
    'Code for official roles. e.g. TMK is for Time Keeper';
    
COMMENT ON COLUMN officialrole.offrole_desc IS
    'Official role description';

ALTER TABLE officialrole ADD CONSTRAINT officialrole_pk PRIMARY KEY ( offrole_code );

ALTER TABLE officialrole ADD CONSTRAINT officialrole_uq UNIQUE ( offrole_desc );

ALTER TABLE officialrole ADD CONSTRAINT officialrole_offrole_code_check CHECK (offrole_code IN ('TMK', 'MAR', 'STR', 'FAD'));

CREATE TABLE official (
    comp_no     NUMBER(5) NOT NULL,
    carn_date   DATE NOT NULL,
    offrole_code CHAR(3) NOT NULL
);

COMMENT ON COLUMN official.comp_no IS
    'Unique number identifier for competitors';
    
COMMENT ON COLUMN official.carn_date IS
    'Date of carnival (unique identifier)';

COMMENT ON COLUMN official.offrole_code IS
    'The official''s role code';

ALTER TABLE official ADD CONSTRAINT official_pk PRIMARY KEY ( comp_no, carn_date );

ALTER TABLE official
    ADD (CONSTRAINT official_competitor_fk FOREIGN KEY ( comp_no )
            REFERENCES competitor (comp_no ),
        CONSTRAINT official_carnival_fk FOREIGN KEY ( carn_date )
            REFERENCES carnival ( carn_date ),
        CONSTRAINT official_offrole_code_fk FOREIGN KEY ( offrole_code )
            REFERENCES officialrole ( offrole_code )
        );

COMMIT;
